<template>
  <div id="app">
    <div class="container">
      <div class="wrapper">
        <router-view />
      </div>
    </div>
  </div>
</template>

<style lang="scss">
.container{
  position: relative;

  *{
    font-family: Roboto, sans-serif;
  }

  width: 100%;

  .wrapper{
    width: 100%;
    max-width: 450px;
    margin: 0 auto;
    padding-left: 16px;
    padding-right: 16px;
    min-height: 100vh;
    position: relative;
  }
}

.home{
  position: relative;
  min-height: 100vh;
}

.btn{
  width: calc(100% - 32px);
  border-radius: 8px;
  font-size: 26px;
  text-transform: uppercase;
  padding-top: 12px;
  padding-bottom: 12px;
  background: transparent;
  outline: none;
  border: 2px solid #000;
  margin-top: 32px;
  position: absolute;
  bottom: 32px;

  &-dark{
    background: #000;
    color: #fff;
  }
}
</style>
