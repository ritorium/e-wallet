import Vue from "vue";
import Vuex from 'vuex';

Vue.use(Vuex);

const store = new Vuex.Store({
state: {
    listCards: []
},
mutations: {
    setListCards(state, val) {
        state.listCards.push(val)
    },
    removeItemFromListCards(state, index){
        state.listCards.splice(index, 0)
        console.log(index)
    }
},
getters: {
    getListCards(state) {
        return state.listCards
    }
},
actions: {
    setListCards({commit}, val) {
        commit('setListCards', val)
    },
    removeItemFromListCards({commit}, index) {
        commit('removeItemFromListCards', index)
    }
}
});

export default store;
