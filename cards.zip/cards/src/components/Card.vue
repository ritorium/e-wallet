<template>
  <div class="card">
    <div class="card-status" v-if="!context">
      NEW card
    </div>
    <div class="card-place" :style="`background: ${getColor};`">
      <div class="vendor-chip">
        <img src="../assets/chip-dark.svg" alt="">
        <img v-show="getVendor === '0'" src="../assets/vendor-bitcoin.svg" alt="">
        <img v-show="getVendor === '1'" src="../assets/vendor-ninja.svg" alt="">
        <img v-show="getVendor === '2'" src="../assets/vendor-blockchain.svg" alt="">
        <img v-show="getVendor === '3'" src="../assets/vendor-evil.svg" alt="">
      </div>
      <div class="card-number">{{ getNumber }}</div>
      <div class="card-footer">
        <div class="name">
          <span>cardholder name</span><br>
          <span>{{ getName }}</span>
        </div>
        <div class="date">
          <span>Valid thru</span><br>
          <span>{{ getDate }}</span>
        </div>
        <!-- <div class="cvv"> -->
          <!-- <span>CVV</span><br> -->
          <!-- <span>{{ getCvv }}</span> -->
        <!-- </div> -->
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Card",
  props: ['number', 'cvv', 'date', 'vendor', 'name', 'context'],
  data() {
    return {
      colors: [
          '#ffb649',
          '#383838',
          '#7a4ddb',
          '#db2e4c'
      ]
    }
  },
  computed: {
    getNumber() {
      return this.number ? this.number.replace(/(\d{4}(?!\s))/g, "$1 ") : 'XXXX XXXX XXXX XXXX'
    },
    getDate() {
      return this.date
    },
    getCvv() {
      return this.cvv
    },
    getVendor() {
      return this.vendor
    },
    getName() {
      return this.name
    },
    getColor() {
      return this.colors[parseInt(this.getVendor)]
    }
  }
};
</script>

<style scoped lang="scss">
.card{
  width: 100%;
  display: flex;
  flex-direction: column;
  &-status{
    width: 100%;
    text-align: center;
    font-size: 14px;
    text-transform: uppercase;
  }
  &-place{
    margin-top: 16px;
    background: #d7d7d7;
    width: 100%;
    padding: 16px;
    border-radius: 8px;
    box-shadow: 0px 0px 5px 1px #999;

    .vendor-chip{
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;

    }
  }
  &-number{
    margin-top: 20px;
    margin-bottom: 16px;
    width: 100%;
    font-size: 24px;
    text-align: center;
    letter-spacing: 5.4px;
  }

  &-footer{
    margin-top: 20px;
    margin-bottom: 20px;
    width: 100%;
    display: flex;
    justify-content: space-between;

    .name{
      span{
        &:first-child{
          font-size: 16px;
          text-transform: uppercase;
        }

        &:last-child{
          font-size: 24px;
          text-transform: uppercase;
        }
      }
    }

    // .cvv{
      // span{
        // &:first-child{
          // font-size: 16px;
          // text-transform: uppercase;
        // }

        // &:last-child{
          // font-size: 24px;
          // text-transform: uppercase;
        // }
      // }
    // }

    .date{
      span{
        &:first-child{
          font-size: 16px;
          text-transform: uppercase;
        }
        &:last-child{
          font-size: 24px;
          text-transform: uppercase;
        }
      }
    }
  }
}




</style>
