<template>
  <div>
    <h1>
      {{ title }}
    </h1>
  </div>
</template>

<script>
export default {
  name: "Top",
  props: ["title"],
};
</script>

<style scoped>
h1 {
  text-align: center;
  display: inline-block;
  width: 100%;
  font-family: Arial, sans-serif;
  padding-top:24px;
  padding-bottom: 24px;
}
</style>
