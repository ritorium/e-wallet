<template>
  <div>
    <Top
      :title="'Add a new banK card'"
    />
    <Card
      :number="newCard.number"
      :date="newCard.date"
      :cvv="newCard.cvv"
      :vendor="newCard.vendor"
      :name="newCard.name"
    />
    <label class="default-label">
      <span>Card Number</span>
      <input maxlength="16" type="tel" v-model="newCard.number">
    </label>
    <label class="default-label">
      <span>cardholder name</span>
      <input type="text" maxlength="16" v-model="newCard.name">
    </label>
    <label class="default-label">
      <span>Valid Thru</span>
      <input type="tel" maxlength="4" v-model="newCard.date" >
    </label>
    <label class="default-label">
       <span>CVV</span>
       <input type="tel" maxlength="3" v-model="newCard.cvv" >
    </label>
    <label class="default-label">
      <select v-model="newCard.vendor">
        <option value="0">bitcoin inc</option>
        <option value="1">Ninja Bank</option>
        <option value="2">Block chain INC</option>
        <option value="3">Evil corp</option>
      </select>
    </label>
    <button @click="addCardToList" class="btn btn-dark">ADD card</button>
  </div>
</template>

<script>
import Top from '../components/Top';
import Card from '../components/Card';

export default {
  name: 'AddCard',
  components: {
    Top,
    Card
  },
  data() {
    return {
      newCard: {
        name: null,
        number: null,
        date: null,
        cvv: null,
        vendor: null
      }
    };
  },
  methods: {
    checkLenght(int, name) {
      this.newCard[name] = this.newCard[name].substr(0, int)
    },
    addCardToList() {
      const obj = {}
      obj.name = this.newCard.name
      obj.number = this.newCard.number
      obj.date = this.newCard.date
      obj.cvv = this.newCard.cvv
      obj.vendor = this.newCard.vendor
      this.$store.dispatch('setListCards', obj)
      this.$router.push('/')
    }
  }
};
</script>

<style scoped lang="scss">
.default-label{
  width: 100%;
  display: flex;
  flex-direction: column;
  padding-top: 16px;
  font-size: 24px;
  color: #000;
  border-radius: 8px;

  span{
    font-size: 14px;
    text-transform: uppercase;
  }

  input{
    width: 100%;
    margin-top: 6px;
    padding: 8px;
    font-size: 24px;
    color: #000;
    border: 1px solid #000;
    border-radius: 8px;
  }
}
</style>
