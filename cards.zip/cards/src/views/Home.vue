<template>
  <div class="home">
    <Top :title="'E-WalLet'"/>
    <Card
      style="padding-bottom: 64px;"
      :number="getSingle.number"
      :date="getSingle.date"
      :cvv="getSingle.cvv"
      :vendor="getSingle.vendor"
      :name="getSingle.name"
    />
    <div class="cards-place">
      <Card
        style="cursor: pointer;"
        v-for="(card, index) in getListCards"
        :key="index"
        :number="card.number"
        :date="card.date"
        :cvv="card.cvv"
        :vendor="card.vendor"
        :name="card.name"
        :context="true"
        @click.native="catchCard(card)"
      >
      </Card>
    </div>
    <button class="btn" @click="$router.push('/add-card')">
      Add a new card
    </button>
  </div>
</template>

<script>
import Top from '../components/Top.vue';
import Card from '../components/Card.vue';

export default {
  name: "Home",
  components: {
    Top,
    Card
  },
  data() {
    return {
      cardSingle: {
        number: null,
        date: null,
        cvv: null,
        vendor: null,
        name: null
      }
    }
  },
  computed: {
    getListCards() {
      return this.$store.getters.getListCards
    },
    getSingle() {
      return this.cardSingle
    }
  },
  methods: {
    catchCard(card) {
        this.cardSingle = card
    }
  }
};
</script>

<style lang="scss">
* {
  margin: 0;
  padding: 0;
  line-height: 1.428;
  box-sizing: border-box;
  text-transform: uppercase;
}
.btn {
  margin-bottom: -120px;
}
.cards-place{
  position: relative;
  padding-bottom: 64px;

  .card{
    &:not(:first-child) {
      position: absolute;
    }
    &:nth-child(2){
      top: calc(20%);
    }
    &:nth-child(3){
      top: calc(20% * 2);
    }
    &:nth-child(4){
      top: calc(20% * 3);
    }
    &:nth-child(5){
      top: calc(20% * 4);
    }
  }
}

</style>
